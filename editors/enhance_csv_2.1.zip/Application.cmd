start loader.exe dir.cc

